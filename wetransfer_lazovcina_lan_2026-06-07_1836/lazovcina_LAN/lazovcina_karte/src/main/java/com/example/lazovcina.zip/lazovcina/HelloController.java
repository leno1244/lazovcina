package com.example.lazovcina;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.InputStream;

public class HelloController {
    @FXML
    private ImageView backgroundImageView;

    @FXML
    public void initialize() {
        try {
            // Ovo traži sliku 'background.jpg' koja stoji u ISTOM folderu unutar resources gde je i FXML
            InputStream stream = getClass().getResourceAsStream("background.jpg");

            if (stream != null) {
                Image image = new Image(stream);
                backgroundImageView.setImage(image);
            } else {
                System.out.println("GREŠKA: Slika nije pronađena u resources folderu!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


